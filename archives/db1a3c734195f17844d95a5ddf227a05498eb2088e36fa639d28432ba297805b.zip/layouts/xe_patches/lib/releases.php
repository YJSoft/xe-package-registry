<?php
/**
 * XE Patches layout: GitHub release reader.
 *
 * Reads the release list of the configured repository from the GitHub API,
 * keeps it in files/cache/xe_patches/ for six hours, and falls back to the
 * stale cache when GitHub cannot be reached.
 * PHP 5.3 syntax only, like the rest of the core.
 */
if(!defined('__XE__')) exit();

if(!function_exists('xe_patches_releases'))
{
	function xe_patches_repo($repo)
	{
		$repo = trim((string)$repo);
		return preg_match('/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/', $repo) ? $repo : '';
	}

	function xe_patches_fetch($url)
	{
		$headers = "User-Agent: xe-patches-layout\r\nAccept: application/vnd.github+json\r\n";
		if(function_exists('curl_init'))
		{
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
			curl_setopt($ch, CURLOPT_TIMEOUT, 4);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: xe-patches-layout', 'Accept: application/vnd.github+json'));
			$body = curl_exec($ch);
			$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			return ($code == 200 && $body) ? $body : false;
		}
		if(ini_get('allow_url_fopen'))
		{
			$context = stream_context_create(array('http' => array('method' => 'GET', 'header' => $headers, 'timeout' => 4)));
			$body = @file_get_contents($url, false, $context);
			return $body ? $body : false;
		}
		return false;
	}

	function xe_patches_normalize($list)
	{
		$out = array();
		if(!is_array($list)) return $out;
		foreach($list as $item)
		{
			if(!is_array($item) || empty($item['tag_name']) || !empty($item['draft'])) continue;
			$tag = (string)$item['tag_name'];
			if(!preg_match('/^[0-9A-Za-z._-]+$/', $tag)) continue;
			$url = isset($item['html_url']) ? (string)$item['html_url'] : '';
			if(strpos($url, 'https://github.com/') !== 0) $url = '';
			$out[] = array(
				'tag' => $tag,
				'name' => isset($item['name']) ? (string)$item['name'] : $tag,
				'date' => isset($item['published_at']) ? substr((string)$item['published_at'], 0, 10) : '',
				'url' => $url,
				'prerelease' => !empty($item['prerelease']),
				'body' => isset($item['body']) ? (string)$item['body'] : '',
			);
		}
		return $out;
	}

	/**
	 * Cache file holding the release list of a repository.
	 */
	function xe_patches_cache_file($repo)
	{
		return _XE_PATH_ . 'files/cache/xe_patches/releases_' . md5(xe_patches_repo($repo)) . '.json';
	}

	/**
	 * Fetches the release list from GitHub now and, when it is not empty,
	 * replaces the cache with it. Returns the fresh list, or an empty array
	 * when GitHub could not be read (the cache is then left alone).
	 */
	function xe_patches_refresh($repo)
	{
		$repo = xe_patches_repo($repo);
		if($repo === '') return array();
		$body = xe_patches_fetch('https://api.github.com/repos/' . $repo . '/releases?per_page=12');
		$fresh = $body ? xe_patches_normalize(json_decode($body, true)) : array();
		if(count($fresh))
		{
			$file = xe_patches_cache_file($repo);
			if(!is_dir(dirname($file))) @mkdir(dirname($file), 0755, true);
			@file_put_contents($file, json_encode($fresh), LOCK_EX);
		}
		return $fresh;
	}

	/**
	 * @return array list of releases, newest first
	 */
	function xe_patches_releases($repo)
	{
		static $memo = array();
		$repo = xe_patches_repo($repo);
		if($repo === '') return array();
		if(isset($memo[$repo])) return $memo[$repo];

		$file = xe_patches_cache_file($repo);
		$ttl = 21600;
		$cached = null;

		if(is_readable($file))
		{
			$cached = json_decode(@file_get_contents($file), true);
			if(is_array($cached) && filemtime($file) > time() - $ttl)
			{
				return $memo[$repo] = $cached;
			}
		}

		$fresh = xe_patches_refresh($repo);
		if(count($fresh))
		{
			return $memo[$repo] = $fresh;
		}

		if(is_array($cached) && count($cached))
		{
			// GitHub unreachable: keep the stale list and try again in 30 minutes.
			@touch($file, time() - $ttl + 1800);
			return $memo[$repo] = $cached;
		}

		return $memo[$repo] = array();
	}

	/** The newest release that is not a pre-release. */
	function xe_patches_latest($releases)
	{
		foreach($releases as $release)
		{
			if(!$release['prerelease']) return $release;
		}
		return count($releases) ? $releases[0] : null;
	}

	/**
	 * The "[RVE-YYYY-NN] text" items of the newest release whose notes list any.
	 * @return array array('release' => release, 'items' => array(array('id' =>, 'text' =>)))
	 */
	function xe_patches_advisories($releases)
	{
		foreach($releases as $release)
		{
			if($release['prerelease'] || $release['body'] === '') continue;
			$items = array();
			if(preg_match_all('/^\s*[*-]\s*\[((?:RVE|CVE)-\d{4}-\d+)\]\s*(.+?)\s*$/m', $release['body'], $m, PREG_SET_ORDER))
			{
				foreach($m as $row)
				{
					$text = preg_replace('/\[([^\]]+)\]\([^)]+\)/', '$1', $row[2]);
					$text = str_replace(array('`', '**'), '', $text);
					$items[] = array('id' => $row[1], 'text' => $text);
				}
			}
			if(count($items)) return array('release' => $release, 'items' => array_slice($items, 0, 6));
		}
		return null;
	}
}
