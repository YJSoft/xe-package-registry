<?php
/**
 * XE Patches layout: values the templates read.
 * Everything printed into HTML attributes or text is prepared here as plain
 * strings; the templates run with autoescape on.
 */
if(!defined('__XE__')) exit();

require_once(dirname(__FILE__) . '/releases.php');

if(!function_exists('xe_patches_is_external'))
{
	/**
	 * True when a menu URL leaves this site: an absolute http(s) or
	 * protocol-relative address on another host. Relative URLs, mids and
	 * this site's own host are internal. Subdomains count as other sites.
	 */
	function xe_patches_is_external($href)
	{
		$href = trim((string)$href);
		if(!preg_match('@^(?:https?:)?//@i', $href)) return false;
		$host = strtolower((string)parse_url((strpos($href, '//') === 0 ? 'https:' : '') . $href, PHP_URL_HOST));
		if($host === '') return false;
		$own = strtolower((string)parse_url(Context::getRequestUri(), PHP_URL_HOST));
		if($own === '' && isset($_SERVER['HTTP_HOST'])) $own = strtolower(preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']));
		return $host !== $own;
	}
}

if(!function_exists('xe_patches_setting'))
{
	/**
	 * A trimmed text setting of the layout, or $default when it is empty.
	 */
	function xe_patches_setting($layout_info, $name, $default = '')
	{
		$value = isset($layout_info->$name) ? trim((string)$layout_info->$name) : '';
		return $value !== '' ? $value : $default;
	}

	/**
	 * URL of an image setting. Uploads live under files/attach/images/;
	 * anything else is ignored.
	 */
	function xe_patches_image_url($path)
	{
		// ModuleHandler hands image settings over as full URLs; admin previews may still pass ./files/...
		$path = trim((string)$path);
		$base = Context::getRequestUri();
		if(strpos($path, $base) === 0) $path = substr($path, strlen($base));
		$path = preg_replace('@^\./@', '', $path);
		if($path === '' || strpos($path, '..') !== false || !preg_match('@^files/attach/images/[0-9A-Za-z_./-]+\.(?:png|jpe?g|gif|svg|webp|ico)$@i', $path)) return '';
		return $base . $path;
	}

	/**
	 * Footer notices: one paragraph per line, keeping only a (http, https, mailto,
	 * relative href), br, strong, em and code. Returns HTML.
	 */
	function xe_patches_legal($text)
	{
		$out = array();
		foreach(preg_split('/\r\n|\r|\n/', (string)$text) as $line)
		{
			$line = trim(strip_tags($line, '<a><br><strong><em><code>'));
			if($line === '') continue;
			$line = preg_replace_callback('@<(/?)(a|br|strong|em|code)\b([^>]*)>@i', 'xe_patches_legal_tag', $line);
			$out[] = '<p>' . $line . '</p>';
		}
		return implode("\n", $out);
	}

	/**
	 * Favicon links from the layout settings (light and dark PNG). With no
	 * setting the site favicon from the admin stays in charge.
	 */
	function xe_patches_favicon_headers($v)
	{
		$light = htmlspecialchars($v->favicon_light, ENT_QUOTES, 'UTF-8');
		$dark = htmlspecialchars($v->favicon_dark, ENT_QUOTES, 'UTF-8');
		if($light !== '' && $dark !== '')
		{
			Context::addHtmlHeader('<link rel="icon" type="image/png" href="' . $light . '" media="(prefers-color-scheme: light)">');
			Context::addHtmlHeader('<link rel="icon" type="image/png" href="' . $dark . '" media="(prefers-color-scheme: dark)">');
		}
		elseif($light !== '')
		{
			Context::addHtmlHeader('<link rel="icon" type="image/png" href="' . $light . '">');
		}
	}

	function xe_patches_legal_tag($m)
	{
		$name = strtolower($m[2]);
		if($m[1] === '/') return $name === 'br' ? '' : '</' . $name . '>';
		if($name === 'br') return '<br />';
		if($name !== 'a') return '<' . $name . '>';
		$href = '';
		if(preg_match('@\bhref\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s>]+))@i', $m[3], $h))
		{
			$href = html_entity_decode(isset($h[4]) && $h[4] !== '' ? $h[4] : (isset($h[3]) && $h[3] !== '' ? $h[3] : $h[2]), ENT_QUOTES, 'UTF-8');
		}
		if(!preg_match('@^(?:https?://|mailto:|/|\./|#)@i', $href) && !preg_match('@^[a-z0-9_./?&=-]+$@i', $href)) $href = '';
		return $href === '' ? '<a>' : '<a href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '">';
	}
}

if(!function_exists('xe_patches_view'))
{
	function xe_patches_view($layout_info, $site_module_info, $current_module_info, $act)
	{
		$v = new stdClass();
		$v->site_name = xe_patches_setting($layout_info, 'site_name');
		if($v->site_name === '')
		{
			$module_config = getModel('module')->getModuleConfig('module');
			$v->site_name = (is_object($module_config) && isset($module_config->siteTitle) && trim((string)$module_config->siteTitle) !== '') ? trim((string)$module_config->siteTitle) : 'XE';
		}
		$v->logo = xe_patches_image_url(isset($layout_info->logo_image) ? $layout_info->logo_image : '');
		$v->logo_footer = xe_patches_image_url(isset($layout_info->logo_image_footer) ? $layout_info->logo_image_footer : '');
		$v->favicon_light = xe_patches_image_url(isset($layout_info->favicon_light) ? $layout_info->favicon_light : '');
		$v->favicon_dark = xe_patches_image_url(isset($layout_info->favicon_dark) ? $layout_info->favicon_dark : '');
		$v->repo = xe_patches_repo(isset($layout_info->github_repo) ? $layout_info->github_repo : '');
		$v->repo_url = $v->repo !== '' ? 'https://github.com/' . $v->repo : '';
		$v->hero_title = xe_patches_setting($layout_info, 'hero_title', '최신 릴리스');
		$v->hero_lead = xe_patches_setting($layout_info, 'hero_lead');
		$v->download_title = xe_patches_setting($layout_info, 'download_title', '내려받기');
		$v->download_lead = xe_patches_setting($layout_info, 'download_lead');
		$v->footer_line = xe_patches_setting($layout_info, 'footer_line');
		$v->footer_legal = xe_patches_legal(isset($layout_info->footer_legal) ? $layout_info->footer_legal : '');

		$is_index = $site_module_info && $current_module_info && $site_module_info->module_srl == $current_module_info->module_srl;
		$v->is_home = $layout_info->use_home !== 'N' && $is_index && $current_module_info->module === 'page' && (!$act || $act === 'dispPageIndex');

		$v->latest = null;
		$v->releases = array();
		$v->advisories = null;
		if($v->is_home && $v->repo !== '')
		{
			$releases = xe_patches_releases($v->repo);
			$v->releases = array_slice($releases, 0, 6);
			$v->latest = xe_patches_latest($releases);
			$v->advisories = xe_patches_advisories($releases);
		}
		if($v->latest)
		{
			$tag = $v->latest['tag'];
			$v->tag = $tag;
			$v->zip = $v->repo_url . '/archive/refs/tags/' . rawurlencode($tag) . '.zip';
			$v->tgz = $v->repo_url . '/archive/refs/tags/' . rawurlencode($tag) . '.tar.gz';
			$v->notes = $v->latest['url'] ? $v->latest['url'] : $v->repo_url . '/releases';
			$v->clone = 'git clone -b ' . $tag . ' ' . $v->repo_url . '.git';
		}
		$v->field_words = array();
		if($v->advisories)
		{
			foreach($v->advisories['items'] as $item) $v->field_words[] = $item['id'];
		}
		$v->field_words = implode(' ', $v->field_words);
		return $v;
	}
}
