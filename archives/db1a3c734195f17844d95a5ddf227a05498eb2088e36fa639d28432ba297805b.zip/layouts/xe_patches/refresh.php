<?php
/**
 * XE Patches layout: refresh the front page release cache from outside.
 *
 *   POST /layouts/xe_patches/refresh.php
 *   Authorization: Bearer <refresh_token set in the layout settings>
 *   tag=<release tag the caller expects to see>   (optional)
 *
 * Responses are JSON:
 *   200 {"ok":true,"latest":"1.11.32","tags":[...]}   cache replaced
 *   409 {"ok":false,"error":"tag_not_visible",...}    GitHub does not list the tag yet; retry later
 *   502 {"ok":false,"error":"github_unreachable"}     GitHub could not be read; cache left alone
 *   401 / 403 / 405 / 404                              method, token or setup problems
 *
 * The token lives in the layout's extra vars (DB), never in this file.
 */
define('__XE__', true);
define('__XE_PATCHES_REFRESH__', true);

function xe_patches_refresh_reply($status, $data)
{
	if(!headers_sent())
	{
		http_response_code($status);
		header('Content-Type: application/json; charset=utf-8');
		header('Cache-Control: no-store');
	}
	echo json_encode($data);
	exit;
}

if(!isset($_SERVER['REQUEST_METHOD']) || strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST')
{
	if(!headers_sent()) header('Allow: POST');
	xe_patches_refresh_reply(405, array('ok' => false, 'error' => 'method_not_allowed'));
}

// Read the bearer token before XE starts (some servers only expose it in one of these)
$auth = '';
if(isset($_SERVER['HTTP_AUTHORIZATION'])) $auth = $_SERVER['HTTP_AUTHORIZATION'];
elseif(isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) $auth = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
elseif(function_exists('getallheaders'))
{
	foreach(getallheaders() as $name => $value)
	{
		if(strtolower($name) === 'authorization') $auth = $value;
	}
}
$token = preg_match('/^Bearer\s+(\S+)$/i', trim($auth), $m) ? $m[1] : '';
$tag = isset($_POST['tag']) ? trim((string)$_POST['tag']) : '';
if($tag !== '' && !preg_match('/^[0-9A-Za-z._-]{1,64}$/', $tag)) $tag = '';

if($token === '')
{
	xe_patches_refresh_reply(401, array('ok' => false, 'error' => 'token_required'));
}

chdir(dirname(__FILE__) . '/../..');
require './config/config.inc.php';
$oContext = Context::getInstance();
$oContext->init();

require_once(_XE_PATH_ . 'layouts/xe_patches/lib/releases.php');

// Every XE Patches layout instance (PC and mobile) may carry a token and a repository
$oLayoutModel = getModel('layout');
$repos = array();
$configured = false;
$no_repo = false;
foreach(array('P', 'M') as $type)
{
	$list = $oLayoutModel->getLayoutList(0, $type);
	if(!is_array($list)) continue;
	foreach($list as $row)
	{
		if($row->layout !== 'xe_patches') continue;
		$output = executeQuery('layout.getLayout', (object)array('layout_srl' => $row->layout_srl));
		$info = ($output->toBool() && $output->data && $output->data->extra_vars) ? unserialize($output->data->extra_vars) : null;
		if(!is_object($info)) continue;
		$expected = isset($info->refresh_token) ? trim((string)$info->refresh_token) : '';
		if(strlen($expected) < 32) continue;
		$configured = true;
		if(function_exists('hash_equals') ? hash_equals($expected, $token) : $expected === $token)
		{
			$repo = xe_patches_repo(isset($info->github_repo) ? $info->github_repo : '');
			if($repo !== '') $repos[$repo] = true;
			else $no_repo = true;
		}
	}
}

if(!$configured)
{
	xe_patches_refresh_reply(404, array('ok' => false, 'error' => 'not_configured'));
}
if(!count($repos))
{
	if(!empty($no_repo)) xe_patches_refresh_reply(404, array('ok' => false, 'error' => 'no_repository'));
	xe_patches_refresh_reply(403, array('ok' => false, 'error' => 'invalid_token'));
}

$result = array('ok' => true, 'repos' => array());
foreach(array_keys($repos) as $repo)
{
	$fresh = xe_patches_refresh($repo);
	if(!count($fresh))
	{
		xe_patches_refresh_reply(502, array('ok' => false, 'error' => 'github_unreachable', 'repo' => $repo));
	}
	$tags = array();
	foreach($fresh as $release) $tags[] = $release['tag'];
	$latest = xe_patches_latest($fresh);
	if($tag !== '' && !in_array($tag, $tags, true))
	{
		xe_patches_refresh_reply(409, array('ok' => false, 'error' => 'tag_not_visible', 'repo' => $repo, 'tag' => $tag, 'latest' => $latest ? $latest['tag'] : null));
	}
	$result['repos'][] = array('repo' => $repo, 'latest' => $latest ? $latest['tag'] : null, 'tags' => $tags);
}
$result['latest'] = $result['repos'][0]['latest'];
xe_patches_refresh_reply(200, $result);
