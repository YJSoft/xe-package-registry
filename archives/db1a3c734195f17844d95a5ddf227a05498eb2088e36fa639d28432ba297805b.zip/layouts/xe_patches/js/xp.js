/* XE Patches layout: the hero's ASCII field and the copy key. No dependencies. */
(function () {
	'use strict';

	/* ---------- copy key ---------- */
	var copyKeys = document.querySelectorAll('[data-copy]');
	if (navigator.clipboard && window.isSecureContext) {
		Array.prototype.forEach.call(copyKeys, function (btn) {
			var status = btn.parentNode.querySelector('[data-copy-status]');
			btn.hidden = false;
			btn.addEventListener('click', function () {
				navigator.clipboard.writeText(btn.getAttribute('data-copy')).then(function () {
					btn.textContent = '복사됨';
					if (status) status.textContent = '명령을 클립보드에 복사했습니다.';
					setTimeout(function () { btn.textContent = '복사'; }, 1600);
				}, function () {
					if (status) status.textContent = '복사하지 못했습니다. 명령을 직접 선택해 복사하세요.';
				});
			});
		});
	}

	/* ---------- ASCII field ----------
	 * An 8 by 16 character grid. The left edge is raw (dense noise with the
	 * advisory ids the latest release fixed); the right edge is resolved
	 * (ordered runs). The centre column stays clear for the type. */
	var canvas = document.querySelector('.xp-field');
	if (!canvas || !canvas.getContext) return;
	var hero = canvas.parentNode;
	var ctx = canvas.getContext('2d');
	var css = getComputedStyle(document.documentElement);
	var tone = function (name) { return css.getPropertyValue(name).trim(); };
	var inks = [tone('--color-glyph-1'), tone('--color-glyph-2'), tone('--color-glyph-3'), tone('--color-glyph-4'), tone('--color-accent-deep')];
	var CW = 8, CH = 16;
	var RAMP = ' .:-=+*#%@';
	var words = (canvas.getAttribute('data-words') || '').split(/\s+/).filter(Boolean);
	if (!words.length) words = ['escape()', 'RVE'];
	var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
	var cols = 0, rows = 0, dpr = 1, running = false, visible = true, last = 0, t = 0;
	var pointer = { x: -1e4, y: -1e4 };
	var budget = 4800; /* the field drifts for under five seconds, then holds; the pointer lens keeps working */
	var labels = [];

	function hash(x, y) {
		var h = x * 374761393 + y * 668265263;
		h = (h ^ (h >>> 13)) * 1274126177;
		return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
	}
	function smooth(a) { return a * a * (3 - 2 * a); }
	function noise(x, y) {
		var xi = Math.floor(x), yi = Math.floor(y), xf = smooth(x - xi), yf = smooth(y - yi);
		var a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
		return a + (b - a) * xf + (c - a) * yf + (a - b - c + d) * xf * yf;
	}

	function resize() {
		var r = hero.getBoundingClientRect();
		dpr = Math.min(window.devicePixelRatio || 1, 2);
		canvas.width = Math.round(r.width * dpr);
		canvas.height = Math.round(r.height * dpr);
		cols = Math.ceil(r.width / CW);
		rows = Math.ceil(r.height / CH);
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.font = '12px "JetBrains Mono", ui-monospace, monospace';
		ctx.textBaseline = 'top';
		labels = [];
		for (var i = 0; r.width >= 720 && i < Math.min(words.length, 6); i++) {
			labels.push({ word: words[i], col: 2 + Math.floor(hash(i, 7) * Math.max(1, cols * 0.14)), row: Math.floor((i + 0.6) * rows / (Math.min(words.length, 6) + 0.4)) });
		}
		draw();
	}

	/* 0 in the centre column, 1 at the edges */
	function edge(u) {
		var d = Math.abs(u - 0.5);
		if (d < 0.27) return 0;
		return Math.min(1, (d - 0.27) / 0.2);
	}

	function draw() {
		var w = cols * CW, h = rows * CH;
		ctx.clearRect(0, 0, w, h);
		var pc = pointer.x / CW, pr = pointer.y / CH;
		for (var y = 0; y < rows; y++) {
			for (var x = 0; x < cols; x++) {
				var u = x / cols;
				var m = edge(u);
				if (m <= 0) continue;
				var v;
				if (u < 0.5) {
					v = noise(x * 0.09 + t * 0.6, y * 0.18 - t * 0.3) * 0.75 + noise(x * 0.3, y * 0.5 + t) * 0.25;
				} else {
					var lane = (y % 3 === 0) ? 1 : 0.35;
					v = lane * (0.55 + 0.45 * noise(x * 0.05 - t * 0.8, y * 0.9));
				}
				var dx = x - pc, dy = (y - pr) * 2;
				var lens = Math.max(0, 1 - Math.sqrt(dx * dx + dy * dy) / 14);
				v = Math.min(1, v * m + lens * 0.35 * m);
				var k = Math.floor(v * (RAMP.length - 1));
				if (k <= 0) continue;
				var ch = u < 0.5 ? RAMP.charAt(k) : (k > 6 ? '=' : k > 3 ? '-' : '.');
				ctx.fillStyle = inks[Math.min(inks.length - 1, Math.floor(v * inks.length))];
				ctx.fillText(ch, x * CW, y * CH);
			}
		}
		ctx.fillStyle = inks[4];
		for (var i = 0; i < labels.length; i++) {
			var l = labels[i];
			ctx.clearRect(l.col * CW - 4, l.row * CH, l.word.length * CW * 0.92 + 8, CH);
			ctx.fillText(l.word, l.col * CW, l.row * CH + 1);
		}
	}

	function frame(now) {
		if (!running) return;
		if (now - last > 33) { budget -= last ? now - last : 33; last = now; t += 0.012; draw(); }
		if (budget <= 0) { running = false; return; }
		requestAnimationFrame(frame);
	}
	function start() {
		if (running || reduce.matches || !visible || budget <= 0) return;
		last = 0;
		running = true;
		requestAnimationFrame(frame);
	}
	function stop() { running = false; }

	hero.classList.add('has-field');
	resize();
	window.addEventListener('resize', function () { resize(); });
	hero.addEventListener('pointermove', function (e) {
		var r = hero.getBoundingClientRect();
		pointer.x = e.clientX - r.left; pointer.y = e.clientY - r.top;
		if (!running) draw();
	});
	hero.addEventListener('pointerleave', function () { pointer.x = pointer.y = -1e4; if (!running) draw(); });
	if ('IntersectionObserver' in window) {
		new IntersectionObserver(function (entries) {
			visible = entries[0].isIntersecting;
			if (visible) start(); else stop();
		}).observe(hero);
	}
	var onReduce = function () { if (reduce.matches) { stop(); draw(); } else start(); };
	if (reduce.addEventListener) reduce.addEventListener('change', onReduce);
	if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { resize(); });
	start();
})();
