<?php
class pagelockerAdminModel extends pagelocker
{
	
}