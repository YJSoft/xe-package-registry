<?php
/**
 * @class pagelocker
 * @author 퍼니XE (contact@funnyxe.com)
 * @brief pagelocker 모듈의 high class
 **/

class pagelocker extends ModuleObject
{
	private $triggers = array(
		// after_module_proc 시점의 trigger
		array('moduleObject.proc', 'pagelocker', 'controller', 'triggerAfterModuleProc','after'),
		// before_display_content 시점의 trigger
		array('display', 'pagelocker', 'controller', 'triggerBeforeDisplayContent', 'before'),
		// 추가 설정 페이지에서 호출되는 trigger
		array('module.dispAdditionSetup', 'pagelocker', 'controller', 'triggerDispAdditionSetup', 'before')
	);

	/**
	 * 모듈 설치
	 **/
	public function moduleInstall()
	{
		return $this->moduleUpdate();
	}

	/**
	 * @brief 업데이트가 필요한지 확인
	 **/
	function checkUpdate()
	{
		// moduleModel 객체 생성
		$oModuleModel = getModel('module');

		// 트리거가 등록되어 있는지 확인
		foreach($this->triggers as $no => $trigger)
		{
			if(!$oModuleModel->getTrigger($trigger[0], $trigger[1], $trigger[2], $trigger[3], $trigger[4]))
			{
				return true;
			}
		}

		return (bool) $oModuleModel->getTrigger('moduleObject.proc', 'pagelocker', 'controller', 'triggerBeforeModuleProc', 'before');
	}

	/**
	* @brief 모듈 업데이트
	**/
	function moduleUpdate()
	{
		// moduleModel 객체 생성
		$oModuleModel = getModel('module');
		// moduleController 객체 생성
		$oModuleController = getController('module');

		if ($oModuleModel->getTrigger('moduleObject.proc', 'pagelocker', 'controller', 'triggerBeforeModuleProc', 'before'))
		{
			$oModuleController->deleteTrigger('moduleObject.proc', 'pagelocker', 'controller', 'triggerBeforeModuleProc', 'before');
		}

		// 트리거 등록
		foreach($this->triggers as $no => $trigger)
		{
			if(!$oModuleModel->getTrigger($trigger[0], $trigger[1], $trigger[2], $trigger[3], $trigger[4]))
			{
				$oModuleController->insertTrigger($trigger[0], $trigger[1], $trigger[2], $trigger[3], $trigger[4]);
			}
		}

		return $this->makeObject(0,'success_updated');
	}

	/**
	 * 모듈 삭제
	 */
	public function moduleUninstall()
	{
		// moduleController 객체 생성
		$oModuleController = getController('module');

		// 트리거 삭제
		foreach($this->triggers as $no => $trigger)
		{
			$oModuleController->deleteTrigger($trigger[0], $trigger[1], $trigger[2], $trigger[3], $trigger[4]);
		}
	}

	/**
	 * @brief 캐시 파일 재생성
	 **/
	public function recompileCache()
	{
	}

	protected function getExpirySeconds($config)
	{
		$units = array('MINUTES' => 60, 'HOURS' => 3600, 'DAYS' => 86400, 'MONTHS' => 2592000);
		$unit = is_string($config->page_auth_expire_time_unit) && isset($units[$config->page_auth_expire_time_unit]) ? $units[$config->page_auth_expire_time_unit] : 1;
		return max(0, (int) $config->page_auth_expire_time) * $unit;
	}

	protected function hasAuthorization($session_key, $id, $duration)
	{
		if (empty($_SESSION[$session_key][$id]) || !isset($_SESSION[$session_key . '_TIME'][$id]))
		{
			return false;
		}
		return !$duration || time() < (int) $_SESSION[$session_key . '_TIME'][$id] + $duration;
	}

    public function makeObject($code = 0, $msg = 'success')
    {
        return class_exists('BaseObject') ? new BaseObject($code, $msg) : new Object($code, $msg);
    }
}