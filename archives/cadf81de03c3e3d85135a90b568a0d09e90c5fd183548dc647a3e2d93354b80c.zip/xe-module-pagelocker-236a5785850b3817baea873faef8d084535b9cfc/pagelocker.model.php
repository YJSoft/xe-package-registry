<?php
class pagelockerModel extends pagelocker
{
	public function getModuleConfig()
	{
		static $config = NULL;
		if(is_null($config))
		{
			$oModuleModel = getModel('module');
			$config = $oModuleModel->getModuleConfig('pagelocker');
			if(!is_object($config))
			{
				$config = new stdClass();
			}
		}

		return $config;
	}

	public function getPagelockerPartConfig($module_srl)
	{
		$config = $module_srl ? getModel('module')->getModulePartConfig('pagelocker', $module_srl) : null;
		$defaults = array(
			'enabled' => 'N', 'use_each_document_lock' => 'N', 'page_lock_type' => 'password',
			'page_password' => '', 'page_auth_expire_time' => 0, 'page_auth_expire_time_unit' => 'MINUTES',
			'page_unlock_point' => 0,
		);
		return (object) array_merge($defaults, (array) $config);
	}
}
