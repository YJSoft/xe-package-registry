<?php

class pagelockerController extends pagelocker
{
	public $pagelockerConfig;

	/**
	 * constructor
	 * @return void
	 */
	public function __construct()
	{
		// pagelockerModel 객체 생성
		$oPagelockerModel = getModel('pagelocker');

		// pagelocker 설정을 쉽게 참조할 수 있도록 멤버 변수에 선언
		$this->pagelockerConfig = $oPagelockerModel->getModuleConfig();
	}

	/**
	 * 페이지 잠금 해제
	 * @return void
	 */
	public function procPagelockerPageAuthorize()
	{
		if (empty($this->module_info->module_srl))
		{
			return $this->makeObject(-1, 'msg_invalid_request');
		}
		$module_srl = $this->module_info->module_srl;
		$config = getModel('pagelocker')->getPagelockerPartConfig($module_srl);
		if ($config->enabled !== 'Y')
		{
			return $this->makeObject(-1, 'msg_invalid_request');
		}

		$session_key = 'XE_PAGE_AUTHORIZED';
		$id = $module_srl;
		$password = $config->page_password;
		if ($config->use_each_document_lock === 'Y')
		{
			$document = getModel('document')->getDocument((int) Context::get('document_srl'));
			if (!$document->isExists() || $document->get('module_srl') != $module_srl)
			{
				return $this->makeObject(-1, 'msg_invalid_request');
			}
			$id = $document->get('document_srl');
			$session_key = 'XE_DOCUMENT_AUTHORIZED';
			$password = $document->getExtraEidValue('lock_password');
		}

		$duration = $this->getExpirySeconds($config);
		$return_url = Context::get('success_return_url');
		if ($this->hasAuthorization($session_key, $id, $duration))
		{
			$this->setRedirectUrl($return_url);
			return;
		}

		$logged_info = Context::get('logged_info');
		$member_srl = isset($logged_info->member_srl) ? $logged_info->member_srl : 0;
		$cost = 0;
		if ($config->page_lock_type === 'point')
		{
			if (!$member_srl)
			{
				return $this->makeObject(-1, 'msg_unlock_login_required');
			}
			$cost = max(0, (int) $config->page_unlock_point);
			$balance = $cost ? (int) getModel('point')->getPoint($member_srl, true) : 0;
			if ($balance < $cost)
			{
				return $this->makeObject(-1, 'msg_not_enough_to_point_for_unlock');
			}
		}
		else
		{
			$input = Context::get('page_password');
			if (!is_string($input) || $input === '')
			{
				return $this->makeObject(-1, '페이지 비밀번호를 입력해주세요.');
			}
			if ($password !== $input)
			{
				return $this->makeObject(-1, '비밀번호가 맞지 않습니다.');
			}
		}

		$args = new stdClass;
		$args->module_srl = $module_srl;
		$args->member_srl = $member_srl;
		$args->time = $duration;
		$args->point = $cost;
		$args->date = date('YmdHis');

		$db = DB::getInstance();
		$db->begin();
		$output = executeQuery('pagelocker.insertPageAuthorizeLog', $args);
		if ($output->toBool() && $cost)
		{
			$debit = getController('point')->setPoint($member_srl, $cost, 'minus');
			if (is_object($debit))
			{
				$output = $debit;
			}
			// Older XE1 releases return null even when setPoint() succeeds.
			elseif ((int) getModel('point')->getPoint($member_srl, true) !== $balance - $cost)
			{
				$output = $this->makeObject(-1, 'msg_not_enough_to_point_for_unlock');
			}
		}
		if (!$output->toBool())
		{
			$db->rollback();
			return $output;
		}
		$db->commit();

		$_SESSION[$session_key][$id] = true;
		$_SESSION[$session_key . '_TIME'][$id] = time();
		$this->setRedirectUrl($return_url);
	}

	/**
	 * after_module_proc 시점에 실행되는 trigger
	 */
	public function triggerAfterModuleProc(&$oModule)
	{
		// view 이외에서는 동작하지 않도록 한다
		$info = $oModule->module_info;
		if (empty($info->module_srl) || !isset($info->module_type) || !in_array($info->module_type, array('view', 'mobile'))
			|| Context::get('act') === 'dispMemberLoginForm')
		{
			return $this->makeObject();
		}

		$config = getModel('pagelocker')->getPagelockerPartConfig($info->module_srl);
		if (!getView('pagelocker')->_isAuthorized($info, $config))
		{
			$oModule->setTemplatePath($this->module_path . 'tpl');
			$oModule->setTemplateFile('page_authorize');
			Context::set('pagelockerConfig', $config);
		}
		return $this->makeObject();
	}

	/**
	 * before_display_content 시점에서 실행되는 trigger
	 */
	public function triggerBeforeDisplayContent(&$output)
	{
		$module_info = Context::get('module_info');
		$act = Context::get('act');

		if($act === 'dispPageAdminPageAdditionSetup' && !empty($module_info->module_srl))
		{
			$oPagelockerModel = getModel('pagelocker');
			$pagelockerConfig = $oPagelockerModel->getPagelockerPartConfig($module_info->module_srl);

			Context::set('pagelockerConfig', $pagelockerConfig);
			$oTemplate = TemplateHandler::getInstance();
			$tpl = $oTemplate->compile($this->module_path . 'tpl', 'addition_setup');

			$setup_content = Context::get('setup_content');
			if (is_string($setup_content) && $setup_content !== '')
			{
				$output = str_replace($setup_content, $setup_content . $tpl, $output);
			}
		}

		return $this->makeObject();
	}

	/** 
	 * 추가 설정 페이지 접근 시 호출되는 trigger
	 */
	public function triggerDispAdditionSetup(&$content)
	{
		// 사이트 정보를 구합니다
		$current_module_info = Context::get('current_module_info');

		$current_module_srl = Context::get('module_srl');
		$current_module_srls = Context::get('module_srls');

		if(!$current_module_srl && !$current_module_srls)
		{
			$current_module_srl = isset($current_module_info->module_srl) ? $current_module_info->module_srl : 0;
			if(!$current_module_srl) return $this->makeObject();
		}

		// memberModel 객체 생성
		$oMemberModel = getModel('member');

		// 생성된 그룹을 가져옵니다
		$group_list = $oMemberModel->getGroups(isset($current_module_info->site_srl) ? $current_module_info->site_srl : 0);
		Context::set('group_list', $group_list);

		$oPagelockerModel = getModel('pagelocker');
		$pagelockerConfig = $oPagelockerModel->getPagelockerPartConfig($current_module_srl);

		Context::set('pagelockerConfig', $pagelockerConfig);

		$oTemplate = TemplateHandler::getInstance();
		$tpl = $oTemplate->compile($this->module_path . 'tpl', 'addition_setup');
		$content .= $tpl;

		return $this->makeObject();
	}
}