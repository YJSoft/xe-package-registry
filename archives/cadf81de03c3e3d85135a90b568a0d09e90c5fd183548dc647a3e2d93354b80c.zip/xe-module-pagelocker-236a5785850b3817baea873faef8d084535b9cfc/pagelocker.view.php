<?php
class pagelockerView extends pagelocker
{
	public function init()
	{
		
	}

	/**
	 * 페이지 인증 검증 함수
	 * @return int | bool
	 */
	public function _isAuthorized($info = null, $config = null)
	{
		$info = $info ?: Context::get('module_info');
		if (empty($info->module_srl)) return false;
		$config = $config ?: getModel('pagelocker')->getPagelockerPartConfig($info->module_srl);
		$logged_info = Context::get('logged_info');
		$grant = Context::get('grant');
		if ($config->enabled !== 'Y' || (isset($logged_info->is_admin) && $logged_info->is_admin === 'Y') || !empty($grant->manager))
		{
			return true;
		}
		$duration = $this->getExpirySeconds($config);
		if ($config->use_each_document_lock === 'Y')
		{
			$document = Context::get('oDocument');
			if ($info->module !== 'board' || !($document instanceof documentItem) || !$document->isExists()) return true;
			$password = $document->getExtraEidValue('lock_password');
			if ($password === '' || $password === null) return true;
			return $this->hasAuthorization('XE_DOCUMENT_AUTHORIZED', $document->get('document_srl'), $duration);
		}
		return $this->hasAuthorization('XE_PAGE_AUTHORIZED', $info->module_srl, $duration);
	}

	/**
	 * 인증 페이지를 컴파일하여 return
	 */
	private function _getAuthorizePage()
	{
		$oTemplate = TemplateHandler::getInstance();
		return $oTemplate->compile('./modules/pagelocker/tpl', 'page_authorize');
	}

	private function getPageContent($method)
	{
		if (!$this->_isAuthorized())
		{
			Context::set('pagelockerConfig', getModel('pagelocker')->getPagelockerPartConfig($this->module_info->module_srl));
			return $this->_getAuthorizePage();
		}
		$page = clone getView('page');
		$page->module_info = $this->module_info;
		$page->init();
		return $page->$method();
	}

	public function _getWidgetContent()
	{
		return $this->getPageContent(__FUNCTION__);
	}

	public function _getArticleContent()
	{
		return $this->getPageContent(__FUNCTION__);
	}

	public function _getOutsideContent()
	{
		return $this->getPageContent(__FUNCTION__);
	}
}
