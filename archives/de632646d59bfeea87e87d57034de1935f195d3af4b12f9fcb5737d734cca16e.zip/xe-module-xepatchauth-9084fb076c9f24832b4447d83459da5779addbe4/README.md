# xepatchauth: XE 계정 OAuth 로그인

XpressEngine 1.x 회원 계정으로 외부 서비스 한 곳에 로그인할 수 있게 하는 OpenID Connect 제공자 모듈입니다. [XE Patches](https://xe-patches.c01.kr/) 자료실 로그인에 쓰려고 만들었습니다.

- 인가 코드 흐름 + PKCE(S256)만 지원합니다. 클라이언트는 설정 파일에 적은 한 곳뿐입니다.
- 로그인은 XE의 기본 로그인(`procMemberLogin`)을 그대로 쓰므로 스팸필터 캡차(Turnstile, reCAPTCHA)도 그대로 적용됩니다. 캡차를 켜 두면 로그인 화면에 위젯을 표시합니다.
- 클라이언트에는 닉네임과 서비스별 고유 식별자(`sub`)만 넘깁니다. 차단·기간 제한·비밀번호 변경 주기를 넘긴 회원은 로그인할 수 없습니다.
- ID 토큰은 RS256으로 서명하고, 공개키는 `/oauth/jwks`로 제공합니다.

## 요구 사항

- XpressEngine 1.x, PHP 8.2 이상 (cURL, OpenSSL)
- Apache (`mod_rewrite`) 또는 같은 주소 연결이 가능한 웹 서버
- HTTPS, MySQL(InnoDB)
- Composer

## 설치

1. 저장소 내용을 `modules/xepatchauth/`에 넣고, 그 폴더에서 의존성을 설치합니다.

   ```
   composer install --no-dev --optimize-autoloader
   ```

2. 설정 폴더를 만듭니다. 기본 위치는 `/etc/xe-patchauth/`이고, `config/config.user.inc.php`에서 바꿀 수 있습니다.

   ```php
   define('XEPATCHAUTH_CONFIG_DIR', '/srv/xe-private/xepatchauth');
   ```

   폴더에는 다음 파일을 둡니다. 웹 서버 사용자만 읽을 수 있게 하고(예: `root:www-data`, 640), 웹 문서 루트 밖에 두세요.

   | 파일 | 내용 |
   | --- | --- |
   | `settings.json` | 주소와 화면 설정 ([examples/settings.json](examples/settings.json)) |
   | `signing.pem` | ID 토큰 서명용 RSA 개인키 |
   | `public.pem` | 위 키의 공개키 |
   | `client.sha256` | 클라이언트 비밀값의 SHA-256 (16진수) |
   | `previous-jwk.json` | (선택) 키 교체 중 함께 공개할 이전 공개키 JWK |

   ```
   openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out signing.pem
   openssl pkey -in signing.pem -pubout -out public.pem
   printf '%s' "$CLIENT_SECRET" | sha256sum | cut -d' ' -f1 > client.sha256
   ```

3. 웹 서버에 주소를 연결합니다. Apache 예시는 [examples/apache.conf](examples/apache.conf)에 있습니다. `vendor/`와 `conf/`는 웹에서 막아야 합니다.

4. 관리자 → 설치된 모듈에서 "XE 계정 OAuth 로그인"을 설치하면 필요한 DB 테이블을 만듭니다.

## settings.json

| 키 | 필수 | 설명 |
| --- | --- | --- |
| `issuer` | 예 | 이 XE 사이트 주소 (`https://` + 호스트, 경로 없음) |
| `client_id` | 예 | 클라이언트 ID |
| `redirect_uri` | 예 | 클라이언트 콜백 주소 (https) |
| `client_name` | | 화면에 표시할 클라이언트 이름. 예: 자료실 |
| `client_url` | | 오류 화면의 "돌아가기" 링크 |
| `site_name` | | 화면 제목과 로고 대체 텍스트 |
| `logo` | | 로고 이미지 경로 (같은 사이트의 `/`로 시작하는 경로) |
| `stylesheets` | | 화면에 먼저 불러올 스타일시트 경로 목록 (같은 사이트의 `/`로 시작하는 경로) |

화면 스타일은 [XE Patches 레이아웃](https://github.com/YJSoft/xe-layout-xepatches)과 [회원 스킨](https://github.com/YJSoft/xe-skin-member-xepatches)의 CSS를 `stylesheets`에 넣는 것을 기준으로 만들었습니다.

## 주소

| 주소 | 용도 |
| --- | --- |
| `GET /.well-known/openid-configuration` | 제공자 정보 |
| `GET /oauth/authorize` | 인가 요청 (`response_type=code`, `scope=openid profile`, S256 PKCE, `state`, `nonce`) |
| `POST /oauth/token` | 코드 교환 (클라이언트 인증: HTTP Basic) |
| `GET /oauth/userinfo` | 닉네임, `sub` (Bearer 토큰) |
| `GET /oauth/jwks` | 서명 공개키 |
| `POST /oauth/member-status` | `sub`의 회원이 지금도 로그인할 수 있는지 (클라이언트 인증) |

`tools/reviewer-subject.php`는 관리자 계정의 `sub`를 출력하는 CLI 도구입니다. 클라이언트 쪽 관리자 권한 연결에 씁니다.

## 라이선스

GPL-2.0-only ([COPYING](COPYING)). `composer install`로 받는 의존성은 각자의 라이선스(MIT, BSD-3-Clause)를 따릅니다.
