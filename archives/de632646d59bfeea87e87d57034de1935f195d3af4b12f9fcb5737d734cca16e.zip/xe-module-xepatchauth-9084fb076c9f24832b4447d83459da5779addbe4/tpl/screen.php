<?php
// SPDX-License-Identifier: GPL-2.0-only
defined('__XE__') || exit;
$escape = static fn($value) => htmlspecialchars($value, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8');
$settings = \XEPatches\Login\Provider::settings();
$client = $settings['client_name'];
$site = $settings['site_name'];
// Korean particle 로/으로 after the client name: 으로 after a final consonant other than ㄹ.
$ro = static function ($word) {
    if (!function_exists('mb_ord') || $word === '') return '(으)로';
    $code = mb_ord(mb_substr($word, -1, 1, 'UTF-8'), 'UTF-8');
    if ($code < 0xAC00 || $code > 0xD7A3) return '(으)로';
    $final = ($code - 0xAC00) % 28;
    return ($final === 0 || $final === 8) ? '로' : '으로';
};
$titles = ['login'=>'본사이트 계정으로 로그인', 'consent'=>$client.' 로그인에 동의하시겠어요?', 'invalid'=>'로그인 요청을 확인할 수 없습니다', 'restricted'=>'회원 상태를 확인해 주세요', 'expired'=>'로그인 요청이 만료되었습니다'];
?>
<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $escape($titles[$screen]) ?><?= $site !== '' ? ' · '.$escape($site) : '' ?></title><meta name="description" content="<?= $escape(trim($site.' 본사이트 계정으로 '.$client.'에 로그인합니다.')) ?>">
<?php foreach ($settings['stylesheets'] as $sheet): ?><link rel="stylesheet" href="<?= $escape($sheet) ?>"><?php endforeach ?><link rel="stylesheet" href="/modules/xepatchauth/tpl/auth.css"></head>
<body class="xp-body"><header class="xp-nav"><div class="container xp-nav__row"><a class="xp-wordmark" href="/"><?php if ($settings['logo'] !== ''): ?><img src="<?= $escape($settings['logo']) ?>" height="32" alt="<?= $escape($site !== '' ? $site : '홈') ?>"><?php else: ?><?= $escape($site !== '' ? $site : '홈으로') ?><?php endif ?></a></div></header>
<main class="container auth-page"><div class="xpm"><h1><?= $escape($titles[$screen]) ?></h1><section class="xpm-panel" aria-label="<?= $escape($titles[$screen]) ?>">
<?php if ($screen === 'login'): ?>
<p><?= $escape($client) ?>에 연결할 본사이트 계정으로 로그인해 주세요.</p>
<?php if ($data['login_error']): ?><p id="login-error" role="alert" tabindex="-1" autofocus><?php if ($data['captcha_error']): ?>보안 확인이 끝나지 않았습니다. 아래 보안 확인을 마친 뒤 다시 로그인해 주세요.<?php elseif ($data['captcha_down']): ?>보안 확인 서버에 연결하지 못했습니다. 잠시 후 다시 시도해 주세요.<?php else: ?>로그인하지 못했습니다. 입력 정보와 계정 상태를 확인해 주세요.<?php endif ?></p><?php endif ?>
<form class="auth-form" method="post" action="/index.php">
<input type="hidden" name="module" value="member"><input type="hidden" name="act" value="procMemberLogin">
<input type="hidden" name="ruleset" value="@login"><input type="hidden" name="xe_validator_id" value="modules/member/skins">
<input type="hidden" name="success_return_url" value="<?= $escape($data['return']) ?>"><input type="hidden" name="error_return_url" value="<?= $escape($data['return']) ?>">
<label for="user_id"><?= $data['email'] ? '이메일 주소' : '아이디' ?></label><input id="user_id" name="user_id" type="<?= $data['email'] ? 'email' : 'text' ?>" autocomplete="username" required <?= $data['login_error'] ? 'aria-describedby="login-error"' : 'autofocus' ?>>
<label for="password">비밀번호</label><input type="password" id="password" name="password" autocomplete="current-password" required <?= $data['login_error'] ? 'aria-describedby="login-error"' : '' ?>>
<?php if (!empty($data['captcha'])): ?><div class="auth-captcha">
<?php if ($data['captcha']['provider'] === 'turnstile'): ?><div class="cf-turnstile" data-sitekey="<?= $escape($data['captcha']['sitekey']) ?>" data-language="ko" data-size="flexible" data-theme="light"></div><script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
<?php else: ?><div class="g-recaptcha" data-sitekey="<?= $escape($data['captcha']['sitekey']) ?>"></div><script src="https://www.google.com/recaptcha/api.js?hl=ko" async defer></script><?php endif ?>
<noscript><p>보안 확인을 위해 브라우저에서 JavaScript를 켜 주세요.</p></noscript></div><?php endif ?>
<button class="xpm-btn xpm-btn--primary xpm-btn--wide" type="submit">로그인</button></form><div class="xpm-panel__foot"><a class="xpm-link" href="/index.php?act=dispMemberFindAccount">계정 찾기</a></div>
<?php elseif ($screen === 'consent'): ?>
<p><strong><?= $escape($data['nickname']) ?></strong> 계정으로 <?= $escape(trim($site.' '.$client)) ?>에 로그인합니다.</p>
<p><?= $escape($client) ?>에 <strong>닉네임</strong>과 <strong>계정을 구분하는 고유 식별자</strong>를 제공합니다.</p>
<form method="post" action="/oauth/consent"><input type="hidden" name="request" value="<?= $escape($data['id']) ?>">
<input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>"><div class="choices">
<button class="xpm-btn xpm-btn--primary" name="decision" value="approve">동의하고 <?= $escape($client.$ro($client)) ?> 이동</button><button class="xpm-btn" name="decision" value="deny">취소</button></div></form>
<?php elseif ($screen === 'restricted'): ?><p>본사이트에서 계정 상태와 비밀번호 변경 여부를 확인한 뒤 다시 로그인해 주세요.</p><a href="/index.php?act=dispMemberInfo">회원 정보로 이동</a>
<?php else: ?><p><?= $escape($client) ?>에서 로그인을 다시 시작해 주세요.</p><?php if ($settings['client_url'] !== ''): ?><a href="<?= $escape($settings['client_url']) ?>"><?= $escape($client.$ro($client)) ?> 돌아가기</a><?php endif ?><?php endif ?>
</section></div></main></body></html>
