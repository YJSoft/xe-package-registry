<?php
// SPDX-License-Identifier: GPL-2.0-only
defined('__XE__') || exit;
use XEPatches\Login\Provider;

class xepatchauthView extends xepatchauth
{
    /**
     * The spam filter CAPTCHA (Turnstile or reCAPTCHA) the native procMemberLogin
     * will demand from this visitor, decided by the same rules its trigger uses.
     * Returns ['provider'=>..., 'sitekey'=>...] or null when no CAPTCHA applies.
     */
    private function loginCaptcha()
    {
        if (!class_exists('SpamfilterCaptcha')) {
            $file = _XE_PATH_.'modules/spamfilter/captcha/Captcha.php';
            if (!is_readable($file)) return null;
            require_once $file;
        }
        if (!SpamfilterCaptcha::enabled()) return null;
        $config = SpamfilterCaptcha::config();
        if (!in_array($config->provider ?? '', ['turnstile', 'recaptcha'], true) || empty($config->site_key)) return null;
        $user = Context::get('logged_info');
        $targets = array_change_key_case(SpamfilterCaptcha::targets($config->rules ?? [], Mobile::isFromMobilePhone() ? 'mobile' : 'pc', Context::get('mid'), $user), CASE_LOWER);
        $policy = $targets['procmemberlogin'] ?? null;
        if (!$policy) return null;
        $scope = SpamfilterCaptcha::site().':'.($config->revision ?? '').':'.(is_object($user) && isset($user->member_srl) ? $user->member_srl : 0);
        if ($policy !== 'every_time' && !empty($_SESSION['spamfilter_captcha'][$scope][$policy])) return null;
        Context::loadLang(_XE_PATH_.'modules/spamfilter/lang');
        return ['provider'=>$config->provider, 'sitekey'=>(string)$config->site_key];
    }

    function dispXepatchauthAuthorize()
    {
        $p = $_GET;
        if ($_SERVER['REQUEST_METHOD'] !== 'GET' || ($p['client_id'] ?? null) !== Provider::clientId() || ($p['redirect_uri'] ?? null) !== Provider::callback() ||
            ($p['response_type'] ?? null) !== 'code' || ($p['scope'] ?? null) !== 'openid profile' || ($p['code_challenge_method'] ?? null) !== 'S256') $this->screen('invalid', [], 400);
        foreach (['state','nonce','code_challenge'] as $k) {
            if (!is_string($p[$k] ?? null) || !preg_match('/^[A-Za-z0-9_-]{22,128}$/D',$p[$k])) $this->screen('invalid', [], 400);
        }
        if (strlen($p['code_challenge']) !== 43) $this->screen('invalid', [], 400);
        $requests = array_filter($_SESSION['xepatchauth'] ?? [], static fn($r) => $r['expires'] > time());
        $requests = array_slice($requests, -15, null, true);
        $id = bin2hex(random_bytes(16));
        $requests[$id] = ['challenge'=>$p['code_challenge'],'state'=>$p['state'],'nonce'=>$p['nonce'],'csrf'=>bin2hex(random_bytes(32)),'expires'=>time()+600];
        $_SESSION['xepatchauth'] = $requests;
        $this->redirectTo(Provider::issuer().'/oauth/continue?request='.$id);
    }

    function dispXepatchauthContinue()
    {
        $id = $_GET['request'] ?? '';
        $request = $this->pending($id);
        $member = (int)(Context::get('logged_info')->member_srl ?? 0);
        if (!Context::get('is_logged') || !$member) {
            $config = getModel('module')->getModuleConfig('member');
            $captcha = $this->loginCaptcha();
            $error = !empty($_SESSION['XE_VALIDATOR_ERROR']) || (bool)Context::get('XE_VALIDATOR_ERROR');
            $message = (string)Context::get('XE_VALIDATOR_MESSAGE');
            $captchaError = $error && $captcha && $message !== '' && in_array($message, [Context::getLang('msg_captcha_required'), 'msg_captcha_required'], true);
            $captchaDown = $error && $message !== '' && in_array($message, [Context::getLang('msg_captcha_connection'), 'msg_captcha_connection'], true);
            $this->screen('login', ['return'=>Provider::issuer().'/oauth/continue?request='.$id, 'email'=>($config->identifier ?? 'email_address') !== 'user_id',
                'login_error'=>$error, 'captcha'=>$captcha, 'captcha_error'=>$captchaError, 'captcha_down'=>$captchaDown]);
        }
        $profile = (new Provider())->eligible($member);
        if (!$profile) $this->screen('restricted', [], 403);
        $_SESSION['xepatchauth'][$id]['member'] = $member;
        $this->screen('consent', ['id'=>$id,'csrf'=>$request['csrf'],'nickname'=>html_entity_decode($profile['nick_name'], ENT_QUOTES|ENT_HTML5,'UTF-8')]);
    }
}
