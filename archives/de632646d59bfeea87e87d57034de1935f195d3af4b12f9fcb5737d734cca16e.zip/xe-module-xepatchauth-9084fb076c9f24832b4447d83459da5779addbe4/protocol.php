<?php
// SPDX-License-Identifier: GPL-2.0-only
// Apache maps only these public back-channel URLs to this entry point.
use XEPatches\Login\Provider;

$path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
function respond($status, array $body): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('Referrer-Policy: no-referrer');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($body, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    exit;
}
$paths = ['/.well-known/openid-configuration'=>'GET','/oauth/jwks'=>'GET','/oauth/token'=>'POST','/oauth/userinfo'=>'GET','/oauth/member-status'=>'POST'];
if (!isset($paths[$path])) respond(404,['error'=>'not_found']);
if ($paths[$path] !== $_SERVER['REQUEST_METHOD']) {
    header('Allow: '.$paths[$path]);
    respond(405,['error'=>'invalid_request']);
}
try {
    define('__XE__', true);
    require dirname(__DIR__,2).'/config/config.inc.php';
    require_once __DIR__.'/Provider.php';
    $issuer = Provider::issuer();
    if ($path === '/.well-known/openid-configuration') respond(200,[
        'issuer'=>$issuer,'authorization_endpoint'=>$issuer.'/oauth/authorize','token_endpoint'=>$issuer.'/oauth/token','userinfo_endpoint'=>$issuer.'/oauth/userinfo','jwks_uri'=>$issuer.'/oauth/jwks',
        'response_types_supported'=>['code'],'grant_types_supported'=>['authorization_code'],'subject_types_supported'=>['pairwise'],
        'id_token_signing_alg_values_supported'=>['RS256'],'scopes_supported'=>['openid','profile'],'claims_supported'=>['sub','nickname','iss','aud','iat','exp','nonce'],
        'token_endpoint_auth_methods_supported'=>['client_secret_basic'],'code_challenge_methods_supported'=>['S256'],'authorization_response_iss_parameter_supported'=>true]);
    if ($path === '/oauth/jwks') respond(200,Provider::jwks());
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($path === '/oauth/token' || $path === '/oauth/member-status') {
        if (!str_starts_with(strtolower($_SERVER['CONTENT_TYPE'] ?? ''),'application/x-www-form-urlencoded')) respond(400,['error'=>'invalid_request']);
        $user = $_SERVER['PHP_AUTH_USER'] ?? '';
        $pass = $_SERVER['PHP_AUTH_PW'] ?? '';
        if (!$user && preg_match('/^Basic ([A-Za-z0-9+\/=]+)$/iD',$auth,$m)) {
            [$user,$pass] = array_pad(explode(':',(string)base64_decode($m[1],true),2),2,'');
        }
        // RFC 6749 section 2.3.1 encodes each component before HTTP Basic.
        if (urldecode($user) !== Provider::clientId() || !hash_equals(trim(file_get_contents(Provider::configDir().'client.sha256')),hash('sha256',urldecode($pass)))) {
            header('WWW-Authenticate: Basic realm="'.preg_replace('/[^A-Za-z0-9._-]/', '', Provider::clientId()).'"');
            respond(401,['error'=>'invalid_client']);
        }
        if ($path === '/oauth/member-status') {
            $subject = $_POST['subject'] ?? null;
            if (!is_string($subject) || !preg_match('/^[a-f0-9]{64}$/D',$subject)) respond(400,['error'=>'invalid_request']);
            Context::getInstance()->loadDBInfo();
            respond(200,(new Provider())->subjectStatus($subject, ($_POST['check'] ?? '') === 'admin'));
        }
        if (($_POST['grant_type'] ?? null) !== 'authorization_code') respond(400,['error'=>'unsupported_grant_type']);
        $code = $_POST['code'] ?? null;
        $verifier = $_POST['code_verifier'] ?? null;
        if (($_POST['redirect_uri'] ?? null) !== Provider::callback() || !is_string($code) || !preg_match('/^[A-Za-z0-9_-]{43}$/D',$code) ||
            !is_string($verifier) || !preg_match('/^[A-Za-z0-9._~-]{43,128}$/D',$verifier)) respond(400,['error'=>'invalid_grant']);
        Context::getInstance()->loadDBInfo();
        $tokens = (new Provider())->exchange($code,$verifier);
        if (!$tokens) respond(400,['error'=>'invalid_grant']);
        respond(200,$tokens);
    }
    if (preg_match('/^Bearer ([A-Za-z0-9_-]{43})$/iD',$auth,$m)) {
        Context::getInstance()->loadDBInfo();
        $profile = (new Provider())->profile($m[1]);
        if ($profile) respond(200,$profile);
    }
    header('WWW-Authenticate: Bearer error="invalid_token"');
    respond(401,['error'=>'invalid_token']);
} catch (Throwable $e) {
    error_log('xepatchauth protocol failed: '.get_class($e).' at '.basename($e->getFile()).':'.$e->getLine());
    respond(500,['error'=>'server_error']);
}
