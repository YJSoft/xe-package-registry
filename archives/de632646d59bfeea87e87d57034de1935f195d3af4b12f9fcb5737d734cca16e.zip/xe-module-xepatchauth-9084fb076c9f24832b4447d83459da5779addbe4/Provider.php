<?php
// SPDX-License-Identifier: GPL-2.0-only
namespace XEPatches\Login;

use DateTimeImmutable;
use Lcobucci\JWT\Encoding\{ChainedFormatter, JoseEncoder};
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Signer\Rsa\Sha256;
use Lcobucci\JWT\Token\Builder;
use League\OAuth2\Server\CodeChallengeVerifiers\S256Verifier;
use PDO;

defined('__XE__') || exit;
require_once __DIR__.'/vendor/autoload.php';

final class Provider
{
    private static ?array $settings = null;
    private PDO $db;
    private string $prefix;

    /**
     * Folder with settings.json and the keys (signing.pem, public.pem, client.sha256).
     * Define XEPATCHAUTH_CONFIG_DIR in config/config.user.inc.php to move it.
     */
    public static function configDir(): string
    {
        $dir = defined('XEPATCHAUTH_CONFIG_DIR') ? (string)XEPATCHAUTH_CONFIG_DIR : '/etc/xe-patchauth';
        return rtrim($dir, '/').'/';
    }

    /**
     * settings.json: issuer, client_id and redirect_uri are required; client_name,
     * client_url, site_name, logo and stylesheets only change the login screens.
     */
    public static function settings(): array
    {
        if (self::$settings !== null) return self::$settings;
        $file = self::configDir().'settings.json';
        $data = is_readable($file) ? json_decode((string)file_get_contents($file), true, 8, JSON_THROW_ON_ERROR) : null;
        if (!is_array($data)) throw new \RuntimeException('xepatchauth: '.$file.' is missing or unreadable');
        foreach (['issuer', 'client_id', 'redirect_uri'] as $key) {
            if (!is_string($data[$key] ?? null) || $data[$key] === '') throw new \RuntimeException('xepatchauth: settings.json needs '.$key);
        }
        $data['issuer'] = rtrim($data['issuer'], '/');
        if (!preg_match('@^https://[^/?#]+$@D', $data['issuer']) || !preg_match('@^https://[^?#]+$@D', $data['redirect_uri'])) {
            throw new \RuntimeException('xepatchauth: issuer and redirect_uri must be https URLs (issuer without a path)');
        }
        $local = static fn($path) => is_string($path) && preg_match('@^/(?!/)[A-Za-z0-9_./-]+$@D', $path) && !str_contains($path, '..');
        $data['client_name'] = is_string($data['client_name'] ?? null) && $data['client_name'] !== '' ? $data['client_name'] : '연결된 서비스';
        $data['client_url'] = is_string($data['client_url'] ?? null) && preg_match('@^https?://@', $data['client_url']) ? $data['client_url'] : '';
        $data['site_name'] = is_string($data['site_name'] ?? null) ? $data['site_name'] : '';
        $data['logo'] = $local($data['logo'] ?? null) ? $data['logo'] : '';
        $data['stylesheets'] = array_values(array_filter(is_array($data['stylesheets'] ?? null) ? $data['stylesheets'] : [], $local));
        return self::$settings = $data;
    }

    public static function issuer(): string { return self::settings()['issuer']; }
    public static function clientId(): string { return self::settings()['client_id']; }
    public static function callback(): string { return self::settings()['redirect_uri']; }

    public function __construct()
    {
        $cfg = \Context::getDBInfo()->master_db;
        $prefix = rtrim($cfg['db_table_prefix'], '_');
        if (!preg_match('/^[a-z0-9_]*$/iD', $prefix)) throw new \RuntimeException('Invalid table prefix');
        $this->prefix = $prefix === '' ? '' : $prefix.'_';
        $this->db = new PDO('mysql:host='.$cfg['db_hostname'].';port='.($cfg['db_port'] ?: 3306).';dbname='.$cfg['db_database'].';charset=utf8mb4',
            $cfg['db_userid'], $cfg['db_password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]);
    }

    private function query(string $sql, array $args = []): \PDOStatement
    {
        $stmt = $this->db->prepare(str_replace('@', $this->prefix, $sql));
        $stmt->execute($args);
        return $stmt;
    }

    public function install(): void
    {
        $this->query('CREATE TABLE IF NOT EXISTS @xepatchauth_subject (member_srl BIGINT PRIMARY KEY, subject CHAR(64) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_bin');
        $this->query('CREATE TABLE IF NOT EXISTS @xepatchauth_code (digest CHAR(64) PRIMARY KEY, member_srl BIGINT NOT NULL, challenge CHAR(43) NOT NULL, nonce VARCHAR(128) NOT NULL, expires BIGINT NOT NULL, INDEX(expires)) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_bin');
        $this->query('CREATE TABLE IF NOT EXISTS @xepatchauth_token (digest CHAR(64) PRIMARY KEY, member_srl BIGINT NOT NULL, expires BIGINT NOT NULL, INDEX(expires)) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_bin');
    }

    public static function b64(string $bytes): string { return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '='); }

    public function eligible(int $id): ?array
    {
        $row = $this->query('SELECT member_srl, nick_name, is_admin, denied, limit_date, change_password_date FROM @member WHERE member_srl=?', [$id])->fetch(PDO::FETCH_ASSOC);
        if (!$row || $row['denied'] === 'Y' || substr((string)$row['limit_date'], 0, 8) >= date('Ymd')) return null;
        $days = (int)(\getModel('module')->getModuleConfig('member')->change_password_date ?? 0);
        if ($days > 0 && $row['change_password_date'] < date('YmdHis', strtotime("-$days days"))) return null;
        return $row;
    }

    public function activeSubject(string $subject): bool
    {
        return $this->subjectStatus($subject, false)['active'];
    }

    public function subjectStatus(string $subject, bool $checkAdmin): array
    {
        $id = $this->query('SELECT member_srl FROM @xepatchauth_subject WHERE subject=?', [$subject])->fetchColumn();
        $member = $id ? $this->eligible((int)$id) : null;
        $status = ['active'=>$member !== null];
        if ($checkAdmin) $status['admin'] = ($member['is_admin'] ?? 'N') === 'Y';
        return $status;
    }

    public function subjectForMember(int $id): string
    {
        $this->query('INSERT INTO @xepatchauth_subject (member_srl,subject) VALUES (?,?) ON DUPLICATE KEY UPDATE member_srl=member_srl', [$id, bin2hex(random_bytes(32))]);
        return (string)$this->query('SELECT subject FROM @xepatchauth_subject WHERE member_srl=?', [$id])->fetchColumn();
    }

    public function issue(int $member, array $request): string
    {
        $this->query('DELETE FROM @xepatchauth_code WHERE expires<=? LIMIT 100', [time()]);
        $this->query('DELETE FROM @xepatchauth_token WHERE expires<=? LIMIT 100', [time()]);
        $code = self::b64(random_bytes(32));
        $this->query('INSERT INTO @xepatchauth_code (digest,member_srl,challenge,nonce,expires) VALUES (?,?,?,?,?)',
            [hash('sha256', $code), $member, $request['challenge'], $request['nonce'], time()+60]);
        return $code;
    }

    private static function publicKey(): array
    {
        $pem = file_get_contents(self::configDir().'public.pem');
        $rsa = openssl_pkey_get_details(openssl_pkey_get_public($pem))['rsa'];
        return ['kty'=>'RSA','use'=>'sig','alg'=>'RS256','kid'=>substr(hash('sha256', $pem),0,24),
                'n'=>self::b64($rsa['n']), 'e'=>self::b64($rsa['e'])];
    }

    public static function jwks(): array
    {
        $keys = [self::publicKey()];
        if (is_file(self::configDir().'previous-jwk.json')) $keys[] = json_decode(file_get_contents(self::configDir().'previous-jwk.json'), true, 8, JSON_THROW_ON_ERROR);
        return ['keys'=>$keys];
    }

    public function exchange(string $code, string $verifier): ?array
    {
        $digest = hash('sha256', $code);
        $this->db->beginTransaction();
        try {
            $row = $this->query('SELECT * FROM @xepatchauth_code WHERE digest=? FOR UPDATE', [$digest])->fetch(PDO::FETCH_ASSOC);
            if (!$row || $row['expires']<=time() || !(new S256Verifier())->verifyCodeChallenge($verifier,$row['challenge']) || !$this->eligible((int)$row['member_srl'])) {
                $this->db->rollBack();
                return null;
            }
            $id = $row['member_srl'];
            $subject = $this->subjectForMember((int)$id);
            $now = new DateTimeImmutable();
            $jwt = (new Builder(new JoseEncoder(), ChainedFormatter::default()))
                ->withHeader('kid',self::publicKey()['kid'])->issuedBy(self::issuer())->permittedFor(self::clientId())
                ->relatedTo($subject)->issuedAt($now)->expiresAt($now->modify('+5 minutes'))->withClaim('nonce',$row['nonce'])
                ->getToken(new Sha256(), InMemory::file(self::configDir().'signing.pem'))->toString();
            $token = self::b64(random_bytes(32));
            $this->query('INSERT INTO @xepatchauth_token (digest,member_srl,expires) VALUES (?,?,?)',[hash('sha256',$token),$id,time()+300]);
            $this->query('DELETE FROM @xepatchauth_code WHERE digest=?',[$digest]);
            $this->db->commit();
            return ['token_type'=>'Bearer','access_token'=>$token,'expires_in'=>300,'scope'=>'openid profile','id_token'=>$jwt];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function profile(string $token): ?array
    {
        $row = $this->query('SELECT t.member_srl,s.subject FROM @xepatchauth_token t JOIN @xepatchauth_subject s ON s.member_srl=t.member_srl WHERE digest=? AND expires>?', [hash('sha256',$token),time()])->fetch(PDO::FETCH_ASSOC);
        if (!$row || !($member = $this->eligible((int)$row['member_srl']))) return null;
        return ['sub'=>$row['subject'],'nickname'=>html_entity_decode($member['nick_name'],ENT_QUOTES|ENT_HTML5,'UTF-8')];
    }
}
