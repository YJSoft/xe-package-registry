<?php
// SPDX-License-Identifier: GPL-2.0-only
defined('__XE__') || exit;
use XEPatches\Login\Provider;

class xepatchauthController extends xepatchauth
{
    function procXepatchauthConsent()
    {
        $id = $_POST['request'] ?? '';
        $request = $this->pending($id);
        $member = (int)(Context::get('logged_info')->member_srl ?? 0);
        $choice = $_POST['decision'] ?? '';
        $csrf = $_POST['csrf'] ?? null;
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !checkCSRF() || !Context::get('is_logged') || !$member || ($request['member'] ?? null) !== $member ||
            !is_string($csrf) || !hash_equals($request['csrf'],$csrf) || !in_array($choice,['approve','deny'],true)) $this->screen('invalid', [], 403);
        unset($_SESSION['xepatchauth'][$id]);
        $response = ['state'=>$request['state'],'iss'=>Provider::issuer()];
        if ($choice === 'deny') $response['error'] = 'access_denied';
        else {
            $provider = new Provider();
            if (!$provider->eligible($member)) $this->screen('restricted', [], 403);
            $response['code'] = $provider->issue($member,$request);
        }
        $this->redirectTo(Provider::callback().'?'.http_build_query($response));
    }
}
