<?php
// SPDX-License-Identifier: GPL-2.0-only
// Operator CLI. Its single output is the archive-specific subject for a verified XE admin.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if ($argc !== 2 || $argv[1] === '') { fwrite(STDERR,"Usage: reviewer-subject.php XE-account\n"); exit(2); }
define('__XE__', true);
chdir(dirname(__DIR__,3));
// config.user.inc.php may move the settings folder, so load the XE config before reading settings.json.
require 'config/config.inc.php';
require_once dirname(__DIR__).'/Provider.php';
$host = parse_url(\XEPatches\Login\Provider::issuer(), PHP_URL_HOST);
$_SERVER = array_merge($_SERVER, [
    'HTTP_HOST'=>$host,'SERVER_NAME'=>$host,'SERVER_PORT'=>'443','HTTPS'=>'on',
    'REQUEST_METHOD'=>'GET','REQUEST_URI'=>'/index.php','SCRIPT_NAME'=>'/index.php','SCRIPT_FILENAME'=>getcwd().'/index.php',
    'DOCUMENT_ROOT'=>getcwd(),'REMOTE_ADDR'=>'127.0.0.1','HTTP_USER_AGENT'=>'XE archive role administration'
]);
Context::getInstance()->init();
$model = getModel('member');
$ids = array_values(array_unique(array_filter([
    $model->getMemberSrlByUserID($argv[1]),
    $model->getMemberSrlByNickName($argv[1]),
])));
if (count($ids) !== 1) { fwrite(STDERR,"A unique XE account is required.\n"); exit(3); }
$id = (int)$ids[0];
$member = $model->getMemberInfoByMemberSrl($id);
$provider = new \XEPatches\Login\Provider();
if (($member->is_admin ?? 'N') !== 'Y' || !$provider->eligible($id)) {
    fwrite(STDERR,"The account must be an eligible XE administrator.\n"); exit(4);
}
echo $provider->subjectForMember($id);
Context::close();
