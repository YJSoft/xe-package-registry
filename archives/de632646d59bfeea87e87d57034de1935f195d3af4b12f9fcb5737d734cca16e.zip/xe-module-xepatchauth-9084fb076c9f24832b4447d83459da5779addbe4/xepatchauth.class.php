<?php
// SPDX-License-Identifier: GPL-2.0-only
defined('__XE__') || exit;
require_once __DIR__.'/Provider.php';
use XEPatches\Login\Provider;

class xepatchauth extends ModuleObject
{
    function moduleInstall()
    {
        (new Provider())->install();
        return new BaseObject();
    }

    protected function browserHeaders($screen, array $data = [])
    {
        header('Cache-Control: private, no-store');
        // Send only our origin to the native XE login and consent forms.
        header('Referrer-Policy: origin');
        $formDestinations = $screen === 'consent' ? "'self' ".Provider::callback() : "'self'";
        // The login screen may embed the spam filter CAPTCHA; allow only that provider's script and frame.
        $captchaOrigins = [
            'turnstile' => ['script' => 'https://challenges.cloudflare.com', 'frame' => 'https://challenges.cloudflare.com'],
            'recaptcha' => ['script' => 'https://www.google.com/recaptcha/ https://www.gstatic.com/recaptcha/', 'frame' => 'https://www.google.com/recaptcha/ https://recaptcha.google.com/recaptcha/'],
        ];
        $provider = $data['captcha']['provider'] ?? null;
        $extra = isset($captchaOrigins[$provider])
            ? "; script-src {$captchaOrigins[$provider]['script']}; frame-src {$captchaOrigins[$provider]['frame']}; connect-src {$captchaOrigins[$provider]['script']}"
            : '';
        header("Content-Security-Policy: default-src 'none'; style-src 'self'; img-src 'self'; font-src 'self'; form-action $formDestinations; base-uri 'none'; frame-ancestors 'none'$extra");
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
    }

    protected function screen($screen, array $data = [], $status = 200)
    {
        $this->browserHeaders($screen, $data);
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
        require __DIR__.'/tpl/screen.php';
        Context::close();
        exit;
    }

    protected function redirectTo($url)
    {
        header('Cache-Control: private, no-store');
        header('Referrer-Policy: no-referrer');
        header('Location: '.$url,true,303);
        Context::close();
        exit;
    }

    protected function pending($id)
    {
        $record = is_string($id) ? ($_SESSION['xepatchauth'][$id] ?? null) : null;
        if (!$record || $record['expires'] <= time()) $this->screen('expired', [], 400);
        return $record;
    }
}
