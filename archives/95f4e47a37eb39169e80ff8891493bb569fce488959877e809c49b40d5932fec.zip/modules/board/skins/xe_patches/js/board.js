/* XE Patches board skin: the managers' "select all" box. Everything else is XE's own script. */
(function () {
	'use strict';
	var all = document.querySelector('.xpb [data-check-all]');
	if (!all) return;
	all.addEventListener('change', function () {
		Array.prototype.forEach.call(document.querySelectorAll('.xpb input[name="cart"]'), function (box) {
			if (box.checked !== all.checked) box.click();
		});
	});
})();
