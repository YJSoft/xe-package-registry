<?php

namespace Advanced_Mailer;

abstract class Api extends Base
{
	protected function envelopeRecipients()
	{
		return array_keys((array) $this->message->getTo() + (array) $this->message->getCc()
			+ (array) $this->message->getBcc());
	}

	protected function rawMessage()
	{
		// Bcc recipients belong in the API envelope, never in delivered MIME headers.
		$message = clone $this->message;
		$message->getHeaders()->removeAll('Bcc');
		return $message->toString();
	}

	protected function json($data)
	{
		$json = json_encode($data);
		if ($json === false)
		{
			throw new \RuntimeException('Could not encode email as JSON.');
		}
		return $json;
	}

	protected function post($url, $headers, $body, $expectedStatus = 200)
	{
		if (!class_exists('Requests'))
		{
			require_once dirname(__DIR__) . '/vendor/rmccue/requests/library/Requests.php';
			\Requests::register_autoloader();
		}
		$response = \Requests::post($url, $headers, $body, array('follow_redirects' => false, 'timeout' => 30, 'verify' => true));
		$data = json_decode($response->body, true);
		if ($response->status_code != $expectedStatus)
		{
			$detail = '';
			if (isset($data['errors'][0]['message'])) $detail = $data['errors'][0]['message'];
			elseif (isset($data['message'])) $detail = $data['message'];
			elseif (isset($data['Message'])) $detail = $data['Message'];
			throw new \RuntimeException(parse_url($url, PHP_URL_HOST) . ' HTTP ' . $response->status_code . ' ' . $detail);
		}
		if ($expectedStatus !== 202 && !is_array($data))
		{
			throw new \RuntimeException('Invalid JSON response from ' . parse_url($url, PHP_URL_HOST));
		}
		return $data;
	}

	protected function regionalHost($setting, $global, $eu)
	{
		return isset(self::$config->$setting) && self::$config->$setting === 'eu' ? $eu : $global;
	}
}
