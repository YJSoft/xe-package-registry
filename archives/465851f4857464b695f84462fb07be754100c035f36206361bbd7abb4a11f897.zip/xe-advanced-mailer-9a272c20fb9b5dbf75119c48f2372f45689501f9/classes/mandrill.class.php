<?php

namespace Advanced_Mailer;

/**
 * @file mandrill.class.php
 * @author Kijin Sung <kijin@kijinsung.com>
 * @license GPLv2 or Later <https://www.gnu.org/licenses/gpl-2.0.html>
 * @brief Advanced Mailer Transport: Mandrill
 */
require_once __DIR__ . '/api.class.php';

class Mandrill extends Api
{
	public function send()
	{
		$recipients = $this->envelopeRecipients();
		$body = $this->json(array('key' => self::$config->mandrill_api_key,
			'raw_message' => $this->rawMessage(), 'to' => $recipients));
		$result = $this->post('https://mandrillapp.com/api/1.0/messages/send-raw.json', array('Content-Type' => 'application/json'), $body);
		if (!$result || count($result) !== count($recipients))
		{
			throw new \RuntimeException('Mandrill returned an incomplete recipient list.');
		}
		$accepted = true;
		foreach ($result as $recipient)
		{
			if (!isset($recipient['status']) || !in_array($recipient['status'], array('sent', 'queued', 'scheduled'), true))
			{
				$accepted = false;
				$this->errors[] = 'Mandrill: ' . (isset($recipient['email']) ? $recipient['email'] : '')
					. ' ' . (isset($recipient['reject_reason']) ? $recipient['reject_reason'] : 'recipient not accepted');
			}
		}
		return $accepted;
	}
}
