<?php

namespace Advanced_Mailer;

/**
 * @file postmark.class.php
 * @author Kijin Sung <kijin@kijinsung.com>
 * @license GPLv2 or Later <https://www.gnu.org/licenses/gpl-2.0.html>
 * @brief Advanced Mailer Transport: Postmark
 */
require_once __DIR__ . '/api.class.php';

class Postmark extends Api
{
	private function addresses($mailboxes)
	{
		$list = array();
		foreach ((array) $mailboxes as $email => $name)
		{
			$list[] = (string) $name === '' ? $email : '"' . addcslashes($name, '"\\') . '" <' . $email . '>';
		}
		return implode(', ', $list);
	}

	public function send()
	{
		$data = array('From' => $this->addresses($this->message->getFrom()), 'To' => $this->addresses($this->message->getTo()),
			'Subject' => $this->message->getSubject());
		$data[$this->content_type === 'html' ? 'HtmlBody' : 'TextBody'] = $this->message->getBody();
		if ($cc = $this->message->getCc()) $data['Cc'] = $this->addresses($cc);
		if ($bcc = $this->message->getBcc()) $data['Bcc'] = $this->addresses($bcc);
		if ($replyTo = $this->message->getReplyTo()) $data['ReplyTo'] = $this->addresses($replyTo);
		if ($references = $this->message->getHeaders()->get('References'))
		{
			$data['Headers'][] = array('Name' => 'References', 'Value' => $references->getFieldBodyModel());
		}
		foreach ($this->message->getChildren() as $part)
		{
			if (!($part instanceof \Swift_Mime_Attachment)) continue;
			$file = array('Name' => $part->getFilename(), 'ContentType' => $part->getContentType(),
				'Content' => base64_encode($part->getBody()));
			if ($part->getDisposition() === 'inline') $file['ContentID'] = 'cid:' . $part->getId();
			$data['Attachments'][] = $file;
		}
		$headers = array('X-Postmark-Server-Token' => self::$config->postmark_api_key,
			'Accept' => 'application/json', 'Content-Type' => 'application/json');
		$result = $this->post('https://api.postmarkapp.com/email', $headers, $this->json($data));
		if (!isset($result['ErrorCode']) || $result['ErrorCode'] !== 0 || empty($result['MessageID']))
		{
			throw new \RuntimeException(isset($result['Message']) ? 'Postmark: ' . $result['Message'] : 'Invalid Postmark response.');
		}
		return true;
	}
}
