<?php

namespace Advanced_Mailer;

/**
 * @file sendgrid.class.php
 * @author Kijin Sung <kijin@kijinsung.com>
 * @license GPLv2 or Later <https://www.gnu.org/licenses/gpl-2.0.html>
 * @brief Advanced Mailer Transport: SendGrid
 */
require_once __DIR__ . '/api.class.php';

class Sendgrid extends Api
{
	private function addresses($mailboxes)
	{
		$result = array();
		foreach ((array) $mailboxes as $email => $name)
		{
			$address = array('email' => $email);
			if ((string) $name !== '') $address['name'] = $name;
			$result[] = $address;
		}
		return $result;
	}

	public function send()
	{
		if (empty(self::$config->sendgrid_api_key))
		{
			throw new \RuntimeException('SendGrid requires a Mail Send API key.');
		}
		$personalization = array('to' => $this->addresses($this->message->getTo()));
		if ($cc = $this->message->getCc()) $personalization['cc'] = $this->addresses($cc);
		if ($bcc = $this->message->getBcc()) $personalization['bcc'] = $this->addresses($bcc);
		$from = $this->addresses($this->message->getFrom());
		if (!$from) throw new \RuntimeException('SendGrid requires a sender.');
		$data = array(
			'from' => $from[0],
			'personalizations' => array($personalization),
			'subject' => $this->message->getSubject(),
			'content' => array(array('type' => $this->content_type === 'html' ? 'text/html' : 'text/plain',
				'value' => $this->message->getBody())),
		);
		if ($replyTo = $this->message->getReplyTo()) $data['reply_to_list'] = $this->addresses($replyTo);
		if ($references = $this->message->getHeaders()->get('References'))
		{
			$data['headers'] = array('References' => $references->getFieldBodyModel());
		}
		foreach ($this->message->getChildren() as $part)
		{
			if (!($part instanceof \Swift_Mime_Attachment)) continue;
			$file = array('filename' => $part->getFilename(), 'type' => $part->getContentType(),
				'content' => base64_encode($part->getBody()), 'disposition' => $part->getDisposition());
			if ($part->getDisposition() === 'inline') $file['content_id'] = $part->getId();
			$data['attachments'][] = $file;
		}
		$host = $this->regionalHost('sendgrid_api_region', 'api.sendgrid.com', 'api.eu.sendgrid.com');
		$headers = array('Authorization' => 'Bearer ' . self::$config->sendgrid_api_key, 'Content-Type' => 'application/json');
		$this->post('https://' . $host . '/v3/mail/send', $headers, $this->json($data), 202);
		return true;
	}
}
