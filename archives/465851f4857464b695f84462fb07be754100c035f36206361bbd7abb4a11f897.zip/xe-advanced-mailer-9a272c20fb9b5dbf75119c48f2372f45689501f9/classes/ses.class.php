<?php

namespace Advanced_Mailer;

/**
 * @file ses.class.php
 * @author Kijin Sung <kijin@kijinsung.com>
 * @license GPLv2 or Later <https://www.gnu.org/licenses/gpl-2.0.html>
 * @brief Advanced Mailer Transport: Amazon SES
 */
require_once __DIR__ . '/api.class.php';

class Ses extends Api
{
	public function send()
	{
		$region = self::$config->ses_region;
		if (!preg_match('/^[a-z]{2}(?:-[a-z0-9]+)+-[0-9]+$/D', $region))
		{
			throw new \RuntimeException('Invalid Amazon SES region.');
		}
		$host = 'email.' . $region . (strpos($region, 'cn-') === 0 ? '.amazonaws.com.cn' : '.amazonaws.com');
		$path = '/v2/email/outbound-emails';
		$destination = array();
		if ($to = $this->message->getTo()) $destination['ToAddresses'] = array_keys($to);
		if ($cc = $this->message->getCc()) $destination['CcAddresses'] = array_keys($cc);
		if ($bcc = $this->message->getBcc()) $destination['BccAddresses'] = array_keys($bcc);
		$body = $this->json(array(
			'Destination' => $destination,
			'Content' => array('Raw' => array('Data' => base64_encode($this->rawMessage()))),
		));
		$timestamp = gmdate('Ymd\THis\Z');
		$date = substr($timestamp, 0, 8);
		$scope = $date . '/' . $region . '/ses/aws4_request';
		$signedHeaders = 'content-type;host;x-amz-date';
		$canonical = "POST\n" . $path . "\n\ncontent-type:application/json\nhost:" . $host . "\nx-amz-date:" . $timestamp
			. "\n\n" . $signedHeaders . "\n" . hash('sha256', $body);
		$stringToSign = "AWS4-HMAC-SHA256\n" . $timestamp . "\n" . $scope . "\n" . hash('sha256', $canonical);
		$key = 'AWS4' . self::$config->ses_secret_key;
		foreach (array($date, $region, 'ses', 'aws4_request') as $part)
		{
			$key = hash_hmac('sha256', $part, $key, true);
		}
		$headers = array(
			'Content-Type' => 'application/json',
			'X-Amz-Date' => $timestamp,
			'Authorization' => 'AWS4-HMAC-SHA256 Credential=' . self::$config->ses_access_key . '/' . $scope
				. ', SignedHeaders=' . $signedHeaders . ', Signature=' . hash_hmac('sha256', $stringToSign, $key),
		);
		$result = $this->post('https://' . $host . $path, $headers, $body);
		if (empty($result['MessageId'])) throw new \RuntimeException('Amazon SES returned no MessageId.');
		return true;
	}
}
