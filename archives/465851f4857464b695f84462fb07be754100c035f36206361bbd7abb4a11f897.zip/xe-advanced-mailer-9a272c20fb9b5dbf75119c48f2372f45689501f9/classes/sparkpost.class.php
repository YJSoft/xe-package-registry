<?php

namespace Advanced_Mailer;

/**
 * @file sparkpost.class.php
 * @author Kijin Sung <kijin@kijinsung.com>
 * @license GPLv2 or Later <https://www.gnu.org/licenses/gpl-2.0.html>
 * @brief Advanced Mailer Transport: SparkPost
 */
require_once __DIR__ . '/api.class.php';

class SparkPost extends Api
{
	public function send()
	{
		$host = $this->regionalHost('sparkpost_api_region', 'api.sparkpost.com', 'api.eu.sparkpost.com');
		$recipients = array();
		foreach ($this->envelopeRecipients() as $address)
		{
			$recipients[] = array('address' => $address);
		}
		$data = array('options' => array('transactional' => true), 'recipients' => $recipients,
			'content' => array('email_rfc822' => $this->rawMessage()));
		$headers = array('Authorization' => self::$config->sparkpost_api_key, 'Content-Type' => 'application/json');
		$result = $this->post('https://' . $host . '/api/v1/transmissions', $headers, $this->json($data));
		if (!isset($result['results']['total_accepted_recipients'], $result['results']['total_rejected_recipients'])
			|| !$recipients || $result['results']['total_accepted_recipients'] != count($recipients)
			|| $result['results']['total_rejected_recipients'] != 0)
		{
			throw new \RuntimeException('SparkPost did not accept all recipients.');
		}
		return true;
	}
}
