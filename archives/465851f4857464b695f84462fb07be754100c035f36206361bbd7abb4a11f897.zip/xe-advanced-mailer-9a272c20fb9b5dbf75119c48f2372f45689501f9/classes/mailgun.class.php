<?php

namespace Advanced_Mailer;

/**
 * @file mailgun.class.php
 * @author Kijin Sung <kijin@kijinsung.com>
 * @license GPLv2 or Later <https://www.gnu.org/licenses/gpl-2.0.html>
 * @brief Advanced Mailer Transport: Mailgun
 */
require_once __DIR__ . '/api.class.php';

class Mailgun extends Api
{
	public function send()
	{
		$host = $this->regionalHost('mailgun_api_region', 'api.mailgun.net', 'api.eu.mailgun.net');
		$url = 'https://' . $host . '/v3/' . rawurlencode(self::$config->mailgun_domain) . '/messages.mime';
		$boundary = 'xe-' . md5(uniqid('', true));
		$headers = array(
			'Authorization' => 'Basic ' . base64_encode('api:' . self::$config->mailgun_api_key),
			'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
		);
		$body = '--' . $boundary . "\r\nContent-Disposition: form-data; name=\"to\"\r\n\r\n"
			. implode(',', $this->envelopeRecipients()) . "\r\n--" . $boundary
			. "\r\nContent-Disposition: form-data; name=\"message\"; filename=\"message.eml\"\r\n"
			. "Content-Type: message/rfc822\r\n\r\n" . $this->rawMessage() . "\r\n--" . $boundary . "--\r\n";
		$result = $this->post($url, $headers, $body);
		if (empty($result['id'])) throw new \RuntimeException('Mailgun returned no message ID.');
		return true;
	}
}
